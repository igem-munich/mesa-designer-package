![igem_munich_logo](src/mesa_designer/img/dark.png)
# iGEM Munich
iGEM Munich is a TUM & LMU student club focused on participating in the iGEM competition as well as outreach and public 
education. Find more information at: [iGEM Munich](https://igem-munich.com) about our Team or click 
[here](https://igem.org) for more information on the iGEM Competition.

# MESA Designer
The iGEM Munich 2025 MESA Designer Project is a software package focused on easily designing, creating and evaluating different MESA Constructs for any target.
This package extends the functionality of the [MESA-Designer Platform](https://github.com/igem-munich/MESA-Designer) and its API.

## Installation
The mesa-designer python package can be easily installed from pypi using `pip install mesa-designer`. The mesa-designer 
package requires biopython to work and installs this as part of the installation process. Note: any addition dependencies of biopython
will also be installed.

## Requirements
Currently, any python version above 3.10 is supported.  
As part of its installation, mesa-designer also installs biopython and its dependencies. For more information on compatibility, check out [biopython](https://pypi.org/project/biopython/).

## Contributing / Bug Reports
The synthetic biology and bioinformatics community thrives because of international collaboration and community support.
In this spirit any ideas, bug reports and feature requests are very welcome. Please create a new issue on our [GitHub](https://github.com/igem-munich/mesa-designer-package/issues)
and flag it with the appropriate tag.
